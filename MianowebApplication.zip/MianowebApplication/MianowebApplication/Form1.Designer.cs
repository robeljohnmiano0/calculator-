﻿namespace MianowebApplication
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.point = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.equals = new System.Windows.Forms.Button();
            this.addition = new System.Windows.Forms.Button();
            this.subtraction = new System.Windows.Forms.Button();
            this.multiplication = new System.Windows.Forms.Button();
            this.AC = new System.Windows.Forms.Button();
            this.erase = new System.Windows.Forms.Button();
            this.percentage = new System.Windows.Forms.Button();
            this.division = new System.Windows.Forms.Button();
            this.display2 = new System.Windows.Forms.Label();
            this.display1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button8
            // 
            this.button8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button8.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button8.BackColor = System.Drawing.Color.Transparent;
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button8.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("OCR A Extended", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.Transparent;
            this.button8.Location = new System.Drawing.Point(102, 246);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(68, 43);
            this.button8.TabIndex = 8;
            this.button8.Text = " 8 \r\n";
            this.button8.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button7.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button7.BackColor = System.Drawing.Color.Transparent;
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button7.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("OCR A Extended", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.Transparent;
            this.button7.Location = new System.Drawing.Point(28, 246);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(68, 43);
            this.button7.TabIndex = 9;
            this.button7.Text = " 7";
            this.button7.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button6.BackColor = System.Drawing.Color.Transparent;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button6.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("OCR A Extended", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.Transparent;
            this.button6.Location = new System.Drawing.Point(176, 295);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(68, 43);
            this.button6.TabIndex = 10;
            this.button6.Text = " 6 \r\n";
            this.button6.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button5.BackColor = System.Drawing.Color.Transparent;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("OCR A Extended", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.Transparent;
            this.button5.Location = new System.Drawing.Point(102, 295);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(68, 43);
            this.button5.TabIndex = 11;
            this.button5.Text = " 5 \r\n";
            this.button5.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("OCR A Extended", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.Transparent;
            this.button4.Location = new System.Drawing.Point(28, 295);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(68, 43);
            this.button4.TabIndex = 12;
            this.button4.Text = " 4 \r\n";
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("OCR A Extended", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Transparent;
            this.button3.Location = new System.Drawing.Point(176, 344);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(68, 43);
            this.button3.TabIndex = 13;
            this.button3.Text = " 3 \r\n";
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("OCR A Extended", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Transparent;
            this.button2.Location = new System.Drawing.Point(102, 344);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(68, 43);
            this.button2.TabIndex = 14;
            this.button2.Text = " 2\r\n";
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("OCR A Extended", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Transparent;
            this.button1.Location = new System.Drawing.Point(28, 344);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(68, 43);
            this.button1.TabIndex = 15;
            this.button1.Text = " 1 \r\n";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // point
            // 
            this.point.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.point.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.point.BackColor = System.Drawing.Color.Transparent;
            this.point.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.point.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.point.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.point.Font = new System.Drawing.Font("OCR A Extended", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.point.ForeColor = System.Drawing.Color.Transparent;
            this.point.Location = new System.Drawing.Point(102, 393);
            this.point.Name = "point";
            this.point.Size = new System.Drawing.Size(68, 43);
            this.point.TabIndex = 16;
            this.point.Text = " . \r\n";
            this.point.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.point.UseVisualStyleBackColor = false;
            // 
            // button0
            // 
            this.button0.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button0.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button0.BackColor = System.Drawing.Color.Transparent;
            this.button0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button0.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button0.Font = new System.Drawing.Font("OCR A Extended", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button0.ForeColor = System.Drawing.Color.Transparent;
            this.button0.Location = new System.Drawing.Point(28, 393);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(68, 43);
            this.button0.TabIndex = 17;
            this.button0.Text = " 0 \r\n";
            this.button0.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button0.UseVisualStyleBackColor = false;
            this.button0.Click += new System.EventHandler(this.button0_Click);
            // 
            // button9
            // 
            this.button9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button9.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button9.BackColor = System.Drawing.Color.Transparent;
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button9.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("OCR A Extended", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.Transparent;
            this.button9.Location = new System.Drawing.Point(176, 246);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(68, 43);
            this.button9.TabIndex = 18;
            this.button9.Text = " 9 \r\n";
            this.button9.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // equals
            // 
            this.equals.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.equals.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.equals.BackColor = System.Drawing.Color.Transparent;
            this.equals.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.equals.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.equals.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.equals.Font = new System.Drawing.Font("OCR A Extended", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.equals.ForeColor = System.Drawing.Color.Transparent;
            this.equals.Location = new System.Drawing.Point(176, 393);
            this.equals.Name = "equals";
            this.equals.Size = new System.Drawing.Size(170, 43);
            this.equals.TabIndex = 19;
            this.equals.Text = " =";
            this.equals.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.equals.UseVisualStyleBackColor = false;
            // 
            // addition
            // 
            this.addition.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.addition.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.addition.BackColor = System.Drawing.Color.Transparent;
            this.addition.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.addition.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.addition.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addition.Font = new System.Drawing.Font("OCR A Extended", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addition.ForeColor = System.Drawing.Color.Transparent;
            this.addition.Location = new System.Drawing.Point(250, 344);
            this.addition.Name = "addition";
            this.addition.Size = new System.Drawing.Size(96, 43);
            this.addition.TabIndex = 20;
            this.addition.Text = "+\r\n";
            this.addition.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.addition.UseVisualStyleBackColor = false;
            // 
            // subtraction
            // 
            this.subtraction.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.subtraction.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.subtraction.BackColor = System.Drawing.Color.Transparent;
            this.subtraction.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.subtraction.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.subtraction.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.subtraction.Font = new System.Drawing.Font("OCR A Extended", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.subtraction.ForeColor = System.Drawing.Color.Transparent;
            this.subtraction.Location = new System.Drawing.Point(250, 295);
            this.subtraction.Name = "subtraction";
            this.subtraction.Size = new System.Drawing.Size(96, 43);
            this.subtraction.TabIndex = 21;
            this.subtraction.Text = " - \r\n";
            this.subtraction.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.subtraction.UseVisualStyleBackColor = false;
            // 
            // multiplication
            // 
            this.multiplication.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.multiplication.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.multiplication.BackColor = System.Drawing.Color.Transparent;
            this.multiplication.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.multiplication.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.multiplication.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.multiplication.Font = new System.Drawing.Font("OCR A Extended", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.multiplication.ForeColor = System.Drawing.Color.Transparent;
            this.multiplication.Location = new System.Drawing.Point(250, 246);
            this.multiplication.Name = "multiplication";
            this.multiplication.Size = new System.Drawing.Size(96, 43);
            this.multiplication.TabIndex = 22;
            this.multiplication.Text = " x \r\n";
            this.multiplication.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.multiplication.UseVisualStyleBackColor = false;
            // 
            // AC
            // 
            this.AC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AC.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.AC.BackColor = System.Drawing.Color.Transparent;
            this.AC.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.AC.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.AC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AC.Font = new System.Drawing.Font("OCR A Extended", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AC.ForeColor = System.Drawing.Color.Transparent;
            this.AC.Location = new System.Drawing.Point(28, 197);
            this.AC.Name = "AC";
            this.AC.Size = new System.Drawing.Size(68, 43);
            this.AC.TabIndex = 23;
            this.AC.Text = " AC \r\n";
            this.AC.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.AC.UseVisualStyleBackColor = false;
            // 
            // erase
            // 
            this.erase.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.erase.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.erase.BackColor = System.Drawing.Color.Transparent;
            this.erase.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.erase.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.erase.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.erase.Font = new System.Drawing.Font("OCR A Extended", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.erase.ForeColor = System.Drawing.Color.Transparent;
            this.erase.Location = new System.Drawing.Point(102, 197);
            this.erase.Name = "erase";
            this.erase.Size = new System.Drawing.Size(68, 43);
            this.erase.TabIndex = 24;
            this.erase.Text = "  ← \r\n";
            this.erase.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.erase.UseVisualStyleBackColor = false;
            // 
            // percentage
            // 
            this.percentage.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.percentage.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.percentage.BackColor = System.Drawing.Color.Transparent;
            this.percentage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.percentage.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.percentage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.percentage.Font = new System.Drawing.Font("OCR A Extended", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.percentage.ForeColor = System.Drawing.Color.Transparent;
            this.percentage.Location = new System.Drawing.Point(176, 197);
            this.percentage.Name = "percentage";
            this.percentage.Size = new System.Drawing.Size(68, 43);
            this.percentage.TabIndex = 25;
            this.percentage.Text = " % \r\n";
            this.percentage.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.percentage.UseVisualStyleBackColor = false;
            // 
            // division
            // 
            this.division.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.division.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.division.BackColor = System.Drawing.Color.Transparent;
            this.division.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.division.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.division.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.division.Font = new System.Drawing.Font("OCR A Extended", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.division.ForeColor = System.Drawing.Color.Transparent;
            this.division.Location = new System.Drawing.Point(250, 197);
            this.division.Name = "division";
            this.division.Size = new System.Drawing.Size(96, 43);
            this.division.TabIndex = 26;
            this.division.Text = "÷";
            this.division.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.division.UseVisualStyleBackColor = false;
            // 
            // display2
            // 
            this.display2.BackColor = System.Drawing.Color.Transparent;
            this.display2.Font = new System.Drawing.Font("OCR A Extended", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.display2.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.display2.Location = new System.Drawing.Point(28, 35);
            this.display2.Name = "display2";
            this.display2.Size = new System.Drawing.Size(318, 76);
            this.display2.TabIndex = 27;
            this.display2.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // display1
            // 
            this.display1.BackColor = System.Drawing.Color.Transparent;
            this.display1.Font = new System.Drawing.Font("OCR A Extended", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.display1.ForeColor = System.Drawing.Color.DimGray;
            this.display1.Location = new System.Drawing.Point(28, 111);
            this.display1.Name = "display1";
            this.display1.Size = new System.Drawing.Size(318, 59);
            this.display1.TabIndex = 28;
            this.display1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.BackgroundImage = global::MianowebApplication.Properties.Resources.black_desktop_background_geometric_pattern_design_vector_53876_140229;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(379, 459);
            this.Controls.Add(this.display1);
            this.Controls.Add(this.display2);
            this.Controls.Add(this.division);
            this.Controls.Add(this.percentage);
            this.Controls.Add(this.erase);
            this.Controls.Add(this.AC);
            this.Controls.Add(this.multiplication);
            this.Controls.Add(this.subtraction);
            this.Controls.Add(this.addition);
            this.Controls.Add(this.equals);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.point);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button8);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimizeBox = false;
            this.Name = "Calculator";
            this.ShowInTaskbar = false;
            this.Text = "Form1";
            this.TopMost = true;
            this.TransparencyKey = System.Drawing.Color.Black;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button point;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button equals;
        private System.Windows.Forms.Button addition;
        private System.Windows.Forms.Button subtraction;
        private System.Windows.Forms.Button multiplication;
        private System.Windows.Forms.Button AC;
        private System.Windows.Forms.Button erase;
        private System.Windows.Forms.Button percentage;
        private System.Windows.Forms.Button division;
        private System.Windows.Forms.Label display2;
        private System.Windows.Forms.Label display1;
    }
}

